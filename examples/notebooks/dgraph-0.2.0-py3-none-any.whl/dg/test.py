import os
import ctypes

lib_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'diffusion.so')
print(lib_path)
my_lib = ctypes.CDLL(lib_path, use_errno=True)
if my_lib._handle is None:
    errno = ctypes.get_errno()
    raise OSError(errno, os.strerror(errno))
